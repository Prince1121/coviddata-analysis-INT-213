# !pip install folium
# !pip install plotly 

# imports
import plotly.express as px
import plotly.graph_objects as go
import plotly.figure_factory as ff
from plotly.subplots import make_subplots

import folium


import pandas as pd
import numpy as py
import matplotlib.pyplot as plt

%matplotlib inline

import math
import random 
from datetime import timedelta

import warnings
warnings.filterwarnings('ignore')

#color pallette
cnf = '#393e46'
dth = '#ff2e63'
rec = '#21bf73'
act = '#fe9801'

import plotly as py
py.offline.init_notebook_mode(connected = True)  #to access the preprocessed data offline

import os

try:
    os.system("rm -rf Covid-19-Preprocessed-Dataset")
except:
    print('file does not exist')


!git clone https://github.com/laxmimerit/Covid-19-Preprocessed-Dataset.git  #here we are accessing the preprocessed data from gihub


df = pd.read_csv('Covid-19-Preprocessed-Dataset/preprocessed/covid_19_data_cleaned.csv',parse_dates=['Date'])
country_daywise = pd.read_csv('Covid-19-Preprocessed-Dataset/preprocessed/country_daywise.csv',parse_dates=['Date']) #here we are reading the country day wise preprocessed data
countrywise = pd.read_csv('Covid-19-Preprocessed-Dataset/preprocessed/countrywise.csv') #country wise preprocessed data is being readed
daywise = pd.read_csv('Covid-19-Preprocessed-Dataset/preprocessed/daywise.csv',parse_dates=['Date'])#daya wise data is reading


df['Province/State'] = df['Province/State'].fillna("")
df.head()

#table containing the countryday wise data
country_daywise 

#this table showing the countrywise data
countrywise

#This Table is showing the day wise data in world
daywise

#list of confirmed cases in world
confirmed = df.groupby('Date').sum()['Confirmed'].reset_index()
confirmed

Recovered = df.groupby('Date').sum()['Recovered'].reset_index()
Recovered

#list of deaths cases in world
deaths = df.groupby('Date').sum()['Deaths'].reset_index()
deaths

#here we are showin the coloums having null value or not
df.isnull().sum()

#here we are shoing the details of columns in the table
df.info()

#Here we are showing the detail og country INDIA . No. of confirmed cases,deaths,recovered,active,date
df.query('Country == "India"')

#Here we are showing the detail of country US
df.query('Country == "US"')

#HERE WE ARE SHOWING THE LAST 5 DAYS CONFIRMED CASES IN WORLD
confirmed.tail()

#HERE WE ARE SHOWING THE LAST FIVE DAYS RECOVERED CASES IN THE WORLD
Recovered.tail()

#HERE WE ARE SHOWING THE LAST 5 DAYS DEATHS CASES IN THE WORLD
deaths.tail()

#HERE WE ARE PLOTING THE GRAPH WHICH SHOWINH THE NO. CONFIRMED CASE IN WORLD IN RED COLOR
#NO.OF DEATHS IN BLACL COLOR
#NO.OF RECOVERED CASES IN GREEN COLOR
fig = go.Figure()
fig.add_trace(go.Scatter(x = confirmed['Date'], y = confirmed['Confirmed'],mode = 'lines+markers', name = 'Confirmed', line = dict(color = "red", width = 2)) )
fig.add_trace(go.Scatter(x = Recovered['Date'], y = Recovered['Recovered'],mode = 'lines+markers', name = 'Recovered', line = dict(color = "green", width = 5)) )
fig.add_trace(go.Scatter(x = deaths['Date'], y = deaths['Deaths'],mode = 'lines+markers', name = 'Deaths', line = dict(color = "black", width = 1)) )
fig.update_layout(title = 'Worldwide Covid-19-Cases', xaxis_tickfont_size = 14, yaxis = dict(title = 'Number of Cases'))
fig.show()

#HERE WE ARE SHOWING THE DEATAIL OR PROPERITIES OF COLUMNS
df.info()

#HERE WE CONVERTING THE DATE AS STRING TYPE
df['Date'] = df['Date'].astype(str)
df.info()

df.head()

fig = px.density_mapbox(df,lat = 'Lat', lon = 'Long', hover_name = 'Country', hover_data = ['Confirmed', 'Recovered', 'Deaths'], animation_frame='Date', color_continuous_scale='Portland', radius = 7, zoom = 0, height= 700)
fig.update_layout(title = 'Worldwide Covid-19 Cases with Time Laps')
fig.update_layout(mapbox_style = 'open-street-map', mapbox_center_lon = 0)

fig.show()


temp = df.groupby('Date')['Confirmed', 'Deaths', 'Recovered' , 'Active'].sum().reset_index()
temp = temp[temp['Date']==max(temp['Date'])].reset_index(drop = True)

tm = temp.melt(id_vars = 'Date', value_vars = ['Active', 'Deaths', 'Recovered'])
fig = px.treemap(tm, path = ['variable'], values = 'value', height = 250, width = 800, color_discrete_sequence=[act, rec, dth])
fig.data[0].textinfo = 'label+text+value'
fig.show()

temp = df.groupby('Date')['Recovered', 'Deaths', 'Active'].sum().reset_index()
temp = temp.melt(id_vars = 'Date', value_vars = ['Recovered', 'Deaths', 'Active'], var_name = 'Case', value_name = 'Count')

fig = px.area(temp, x = 'Date', y = 'Count', color = 'Case', height = 600, title = 'Cases over time', color_discrete_sequence=[rec, dth, act])
fig.update_layout(xaxis_rangeslider_visible=True)
fig.show()

# worldwise cases on folium maps
temp = df[df['Date']==max(df['Date'])]

m = folium.Map(location=[0, 0], titles='cartodbposition', min_zoom = 1, max_zoom = 4, zoom_start=1)

for i in range(0, len(temp)):
    folium.Circle(location=[temp.iloc[i]['Lat'],temp.iloc[i]['Long']], color = 'crimson', fill = 'crimson',
                  tooltip = '<li><bold> Country: ' + str(temp.iloc[i]['Country'])+
                              '<li><bold> Province: ' + str(temp.iloc[i]['Province/State'])+
                                 '<li><bold> Confirmed: ' + str(temp.iloc[i]['Confirmed'])+
                                    '<li><bold> Deathse: ' + str(temp.iloc[i]['Deaths']),
radius = int(temp.iloc[i]['Confirmed'])**0.5).add_to(m)     
    
m 

#Deaths and recoveries per 100 cases
daywise.head()
fig_c = px.bar(daywise, x = 'Date', y = 'Confirmed', color_discrete_sequence=[act])
fig_d = px.bar(daywise, x = 'Date', y = 'Deaths', color_discrete_sequence=[dth])

fig = make_subplots(rows = 1, cols = 2, shared_xaxes=False, horizontal_spacing=0.1,
                  subplot_titles=('Confirmed Cases', 'Deaths Cases' ))

fig.add_trace(fig_c['data'][0], row = 1, col = 1)
fig.add_trace(fig_d['data'][0], row = 1, col = 2)

fig.update_layout(height = 400)
fig.show()

#showing coloums properties and name of all the column a table contain
daywise.columns
fig1 = px.line(daywise, x = 'Date', y = 'Deaths / 100 Cases', color_discrete_sequence=[dth])
fig2 = px.line(daywise, x = 'Date', y = 'Recovered / 100 Cases', color_discrete_sequence=[rec])
fig3 = px.line(daywise, x = 'Date', y = 'Deaths / 100 Recovered', color_discrete_sequence=[rec])

fig = make_subplots(rows =1, cols = 3,shared_xaxes=False,
                   subplot_titles=('Deaths / 100 Cases', 'Recovered / 100 Cases', 'Deaths / 100 Recovered'))

fig.add_trace(fig1['data'][0], row = 1, col = 1)
fig.add_trace(fig2['data'][0], row = 1, col = 2)
fig.add_trace(fig3['data'][0], row = 1, col = 3)

fig.update_layout(height = 600)
fig.show()

#new cases and No.of countries affected
fig_c = px.bar(daywise, x = 'Date', y = 'Confirmed', color_discrete_sequence=[act])
fig_d = px.bar(daywise, x = 'Date', y = 'No. of Countries', color_discrete_sequence=[dth])

fig = make_subplots(rows = 1, cols = 2, shared_xaxes=False, horizontal_spacing=0.1,
                    subplot_titles=('No.of New Cases per Day','No. of Countries'))
fig.add_trace(fig_c['data'][0], row = 1, col = 1)
fig.add_trace(fig_d['data'][0], row = 1, col = 2)

fig.show()

# top 15 countires of covid virues cases
countrywise.columns
top = 15
 
fig_c = px.bar(countrywise.sort_values('Confirmed').tail(top), x = 'Confirmed', y = 'Country',
              text = 'Confirmed', orientation='h', color_discrete_sequence=[act])   
fig_d = px.bar(countrywise.sort_values('Deaths').tail(top), x = 'Deaths', y = 'Country',
              text = 'Deaths', orientation='h', color_discrete_sequence=[dth])

fig = make_subplots(rows = 5, cols = 2,shared_xaxes=False, horizontal_spacing=0.14,
                   vertical_spacing=0.1,
                   subplot_titles=('Confirmed Cases', 'Deaths Reported'))

fig.add_trace(fig_c['data'][0], row = 1, col = 1)
fig.add_trace(fig_d['data'][0], row = 1, col = 2)

fig.update_layout(height = 3000)

fig.show()


       # THANKU 